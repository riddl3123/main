the secret key has
been locked in a cache of code
a riddle, braintease